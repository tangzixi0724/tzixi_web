/********************************************************
    © 2020 Continuum Graphics LLC. All Rights Reserved
 ********************************************************/

#include "/ContinuumLib/GLSL_Version.glsl"
#define ShaderStage 0
#define WORLD0
#define fsh
#define deferred

#include "/FlipCopy.glsl"
