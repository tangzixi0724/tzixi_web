/********************************************************
    © 2020 Continuum Graphics LLC. All Rights Reserved
 ********************************************************/

#include "/ContinuumLib/GLSL_Version.glsl"
#define ShaderStage 20
#define WORLD0
#define vsh
#define translucent

#include "/GbuffersMain.glsl"
