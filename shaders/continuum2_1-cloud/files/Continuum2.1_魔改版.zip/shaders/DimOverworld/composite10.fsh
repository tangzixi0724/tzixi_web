/********************************************************
    © 2020 Continuum Graphics LLC. All Rights Reserved
 ********************************************************/

#include "/ContinuumLib/GLSL_Version.glsl"
#define ShaderStage 40
#define WORLD0
#define fsh
#define composite7

#include "/Antialiasing.glsl"
