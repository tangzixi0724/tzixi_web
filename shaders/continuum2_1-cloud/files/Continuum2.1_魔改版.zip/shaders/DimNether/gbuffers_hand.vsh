/********************************************************
    © 2020 Continuum Graphics LLC. All Rights Reserved
 ********************************************************/

#include "/ContinuumLib/GLSL_Version.glsl"
#define ShaderStage -1
#define WORLD1
#define vsh
#define hand

#include "/GbuffersMain.glsl"
