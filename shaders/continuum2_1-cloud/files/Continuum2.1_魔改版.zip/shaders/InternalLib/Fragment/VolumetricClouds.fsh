/********************************************************
    © 2020 Continuum Graphics LLC. All Rights Reserved
 ********************************************************/

#if !defined _VOLUMETRICCLOUDS_
#define _VOLUMETRICCLOUDS_

// Coefficients
const float cloudMultiScattCoeff_a = 0.5;
const float cloudMultiScattCoeff_b = 0.5;
const float cloudMultiScattCoeff_c = 0.5;

const float cloudForwardG = 0.8;
const float cloudBackwardG = -0.5;
const float cloudMixG = 0.5;

const float sigmaA = 0.0;                               // Absorption coefficient
const float sigmaS = 0.07;                              // Scattering coefficient
const float sigmaE = sigmaS + sigmaA;                   // Extinction coefficient

float Calculate3DNoise(vec3 position){
    vec3 p = floor(position);
    vec3 b = cubeSmooth(fract(position));

    vec2 uv = 17.0 * p.z + p.xy + b.xy;
    vec2 rg = texture(noisetex, (uv + 0.5) * rNoiseTexRes).xy;

    return mix(rg.x, rg.y, b.z);
}

// Calculate cloud noise using FBM.
float CalculateCloudFBM(vec3 position, vec3 windDirection, const int octaves){
    const float octAlpha = 0.5; // The ratio of visibility between successive octaves
    const float octScale = 3.0; // The downscaling factor between successive octaves
    const float octShift = (octAlpha / octScale) / octaves; // Shift the FBM brightness based on how many octaves are active

    float accum = 0.0;
    float alpha = 0.5;
    vec3  shift = windDirection;
    
	position += windDirection;
    
    for (int i = 0; i < octaves; ++i) {
        accum += alpha * Calculate3DNoise(position);
        position = (position + shift) * octScale;
        alpha *= octAlpha;
    }
    
    return accum + octShift;
}

// Calculate cloud optical depth.
float CalculateCloudDensity(vec3 position, const int octaves){
    // Early out.
    //if (position.y > volumetric_cloudMaxHeight || position.y < volumetric_cloudMinHeight) return 0.0;
    
    float wind          = TIME * volumetric_cloudSpeed * -0.006125;
    vec3  windDirection = vec3(wind, 0.0, wind);
    vec3  cloudPos      = position * 0.00045;
    
    float clouds = CalculateCloudFBM(cloudPos, windDirection, octaves);

    // Doing this early out is pointless since an fmb can rarely ever reach 0.0
	//if (clouds <= 0.0) return 0.0;
    
    float localCoverage = 1.0;

    #ifdef VC_LOCAL_COVERAGE
        localCoverage = texture2D(noisetex, (TIME * volumetric_cloudSpeed * 50.0 + position.xz) * 0.000001 + 0.5).x;
        localCoverage = clamp01(localCoverage * 3.0 - 0.75) * 0.5 + 0.5;
    #endif

    #ifdef RAINY_CLOUDS
        // Rainy overcast: clouds fill more of the sky and get denser.
        float wet = clamp01(wetness);
        localCoverage = mix(localCoverage, localCoverage * 0.4 + 0.6, wet * RAIN_CLOUD_COVERAGE);
    #endif

    float worldHeight       = position.y - volumetric_cloudMinHeight;
    float normalizedHeight  = clamp01(worldHeight / volumetric_cloudThickness);
    float heightAttenuation = RemapClamped(normalizedHeight, 0.0, 0.2, 0.0, 1.0) * RemapClamped(normalizedHeight, 0.8, 1.0, 1.0, 0.0);

    // Calculate the final cloudshape.
    clouds  = clouds * heightAttenuation * localCoverage * volumetric_cloudCoverage * 2.0 - (0.9 * heightAttenuation + normalizedHeight * 0.5 + 0.1);
    clouds  = clamp01(clouds);

    #ifdef RAINY_CLOUDS
        clouds *= mix(1.0, 1.4, clamp01(wetness) * RAIN_CLOUD_DENSITY);
    #endif

    return clouds * volumetric_cloudDensity;
}

float PhaseG(float cosTheta, const float g){
    float gg = g * g;
    return rPI * (gg * -0.25 + 0.25) * pow(-2.0 * (g * cosTheta) + (gg + 1.0), -1.5);
}

float PhaseGDualLobe(float VoL, const float g0, const float g1, const float m){
    float p1 = PhaseG(VoL, g0);
    float p2 = PhaseG(VoL, g1);

    return mix(p2, p1, m);
}

void CalculateMultipleScatteringCloudPhases(float VoL, inout float phases[VC_MULTISCAT_TERMS]){
    float cn = 1.0;
    
    for (int i = 0; i < VC_MULTISCAT_TERMS; ++i){
        phases[i] = PhaseGDualLobe(VoL, cloudForwardG * cn, cloudBackwardG * cn, cloudMixG);

        cn *= cloudMultiScattCoeff_c;
    }
}

float CalculatePowderEffect(float od){
    return 1.0 - exp2(-od * rLOG2 * 2.0);
}

float CalculatePowderEffect(float in_scatter_depth, float in_scatter_height, float VoL){
    float r = VoL * 0.5 + 0.5;
          r = r * r;

    in_scatter_height = in_scatter_height * (1.0 - r) + r;

    return in_scatter_depth * in_scatter_height;
}

float CalculateCloudScatteringIntergral(float transmittanceAtPoint) {
    return (1.0 - transmittanceAtPoint) / sigmaE;
}

float CalculateCloudExtinction(vec3 position, vec3 direction, const int steps){
    float rayLength = 25.0; // Starting ray length

    float extinction = 0.0;

    for (int i = 0; i < steps; ++i, position += direction * rayLength){
		// When the ray goes above of the cloud boundary we make sure to break out of the loop.
		if (position.y >= volumetric_cloudMaxHeight) break;
		
        extinction += CalculateCloudDensity(position, VC_NOISE_OCTAVES) * rayLength;

        rayLength *= 1.5;
    }

    return extinction;
}

float CalculateCloudExtinction(vec3 position){
    return min(volumetric_cloudMinHeight - position.y, volumetric_cloudMinHeight) * (1.0 / volumetric_cloudThicknessMult) * 0.01;
}

float CalculateCloudExtinctionGround(vec3 position) {
    return max0(position.y - volumetric_cloudMinHeight - 100.0) * (volumetric_cloudDensity / volumetric_cloudThicknessMult) * 0.015;
}

void evaluateCloudScattering(float scatteringIntegral, float transmit, float phase, float sigma_l_s, float sigma_l_e, float in_scatter_probability, float in_scatter_indirect, float sunExtinction, float ambientExtinction, float groundExtinction, inout vec3 scattering) {
    vec3 scatteredEnergy = vec3(0.0);
    
    scatteredEnergy.x = exp2(-sunExtinction * rLOG2 * sigma_l_e) * in_scatter_probability * phase;
    scatteredEnergy.y = exp2(-ambientExtinction * rLOG2 * sigma_l_e) * in_scatter_indirect;
    
    #ifdef VC_GROUND_LIGHTING
        scatteredEnergy.z = exp2(-groundExtinction * rLOG2 * sigma_l_e) * in_scatter_indirect;
    #endif

    scattering += scatteredEnergy * scatteringIntegral * transmit * sigma_l_s;
}

void doCloudScattering(float scatteringIntegral, float density, float phases[VC_MULTISCAT_TERMS], vec3 cloudPosition, float VoL, const int dlSteps, float transmit, inout vec3 scattering) {
    float sunExtinction = CalculateCloudExtinction(cloudPosition, wLightVector, dlSteps);
    
    #ifdef VC_HQ_SKYLIGHTING
        float ambientExtinction = CalculateCloudExtinction(cloudPosition, vec3(0.0, 1.0, 0.0), 8) * 0.05;
    #else
        float ambientExtinction = CalculateCloudExtinction(cloudPosition);
    #endif

    #ifdef VC_GROUND_LIGHTING
        float groundExtinction = CalculateCloudExtinctionGround(cloudPosition);
    #else
        float groundExtinction = 0.0;
    #endif

    float worldHeight       = cloudPosition.y - volumetric_cloudMinHeight;
    float normalizedHeight  = clamp01(worldHeight / volumetric_cloudThickness);

    // In-Scattering probability
    float in_scatter_depth = pow(clamp(density * 8.0, 0.0, PI), RemapMaxed(normalizedHeight, 0.3, 0.85, 0.5, 2.0)) + 0.05;
    float in_scatter_height_ms = 1.0 - exp2(-sunExtinction * rLOG2 * sigmaE);
    float in_scatter_height = pow(RemapClamped(normalizedHeight, 0.07, 0.22, 0.9 * in_scatter_height_ms + 0.1, 1.0), 0.8);
    float in_scatter_probability = CalculatePowderEffect(in_scatter_depth, in_scatter_height, VoL);
    float in_scatter_indirect = clamp(density * 8.0, 0.0, PI) * 0.1 + 0.9;
    
    float sigma_l_s = sigmaS;
    float sigma_l_e = sigmaE;

    for (int i = 0; i < VC_MULTISCAT_TERMS; ++i) {
        float phase = phases[i];

        evaluateCloudScattering(scatteringIntegral, transmit, phase, sigma_l_s, sigma_l_e, in_scatter_probability, in_scatter_indirect, sunExtinction, ambientExtinction, groundExtinction, scattering);
    
        sigma_l_s *= cloudMultiScattCoeff_a;
        sigma_l_e *= cloudMultiScattCoeff_b;
    }
}

void calculateVolumetricClouds(inout vec3 cloud, inout float transmit, vec3 wDir, vec3 wLightVector, vec3 worldPosition, vec2 planetSphere, float dither, float VoL, const float planetRadius, const int steps, const int dlSteps){
    #ifndef VOLUMETRIC_CLOUDS
    	return;
    #endif

    // Early out when the clouds are behind the horizon or not visible.
    if ((eyeAltitude < volumetric_cloudMinHeight && planetSphere.y > 0.0)
     || (eyeAltitude > volumetric_cloudMaxHeight &&  wDir.y > 0.0)) return;

    // Calculate the cloud spheres.
    vec2 bottomSphere = rsi(vec3(0.0, planetRadius + eyeAltitude, 0.0), wDir, planetRadius + volumetric_cloudMinHeight);
    vec2    topSphere = rsi(vec3(0.0, planetRadius + eyeAltitude, 0.0), wDir, planetRadius + volumetric_cloudMaxHeight);

    // Get the distance from the eye to the start and endposition.
    float startDist = eyeAltitude > volumetric_cloudMaxHeight ? topSphere.x : bottomSphere.y;
    float   endDist = eyeAltitude > volumetric_cloudMaxHeight ? bottomSphere.x : topSphere.y;

    // Multiply the direction and distance by eachother to.
    vec3 startPos = wDir * startDist;
    vec3   endPos = wDir *   endDist;

    // Calculate the range of when the player is flying through the clouds.
    float marchRange = (1.0 - clamp01((eyeAltitude - volumetric_cloudMaxHeight) * 0.1)) * (1.0 - clamp01((volumetric_cloudMinHeight - eyeAltitude) * 0.1));

    float inCloudRaySpheres = (bottomSphere.y >= 0.0 && eyeAltitude > volumetric_cloudMinHeight ? bottomSphere.x : topSphere.y);
    float inCloudRayDistance = min(inCloudRaySpheres, volumetric_cloudHeight * 10.0);

    // Change the raymarcher's start and endposition when you fly through them or when geometry is behind it.
    startPos = startPos * (1.0 - marchRange) + cameraPosition;
      endPos = mix(endPos, inCloudRayDistance * wDir, marchRange) + cameraPosition;

    // Calculate the ray increment and the ray position.
    vec3  increment     = (endPos - startPos) / steps;
    vec3  rayPosition   = increment * dither + startPos;
    float tLength       = length(increment) * sigmaE;

    vec3 scattering = vec3(0.0);

    float[VC_MULTISCAT_TERMS] phases;
    CalculateMultipleScatteringCloudPhases(VoL, phases);

    vec3  cloudHitPos = vec3(0.0);
    float totTransmit = 0.0;

    // Raymarch through the cloud volume & light the clouds contribution at each step
    for (int i = 0; i < steps; ++i, rayPosition += increment){
        // Curve the cloud position around the Earth.
        vec3 cloudPosition = rayPosition;
             cloudPosition.y = length(cloudPosition + vec3(0.0, planetRadius, 0.0)) - planetRadius;

        float density = CalculateCloudDensity(cloudPosition, VC_NOISE_OCTAVES);
        if (density <= 0.0) { continue; } // Early out.

        float transmittanceAtPoint = exp2(-density * tLength * rLOG2);
        float scatteringIntegral = CalculateCloudScatteringIntergral(transmittanceAtPoint);

        doCloudScattering(scatteringIntegral, density, phases, cloudPosition, VoL, dlSteps, transmit, scattering);

        cloudHitPos += rayPosition * transmit;
        totTransmit += transmit;

        transmit *= transmittanceAtPoint;
		
		if (transmit < 0.001) { transmit = 0.0; break; }
    }

    if (transmit >= 1.0) {
        return;
    }

    // Light the scattering and sum them up.
    vec3 directLighting = scattering.x * sunIlluminanceClouds;
    vec3 skyLighting    = scattering.y * skyIlluminanceClouds;
    
    #ifdef VC_GROUND_LIGHTING
        vec3 groundLighting = sunIlluminanceClouds * abs(wLightVector.y) + skyIlluminanceClouds;
             groundLighting *= scattering.z * rPI * 0.2;
    #else
        vec3 groundLighting = vec3(0.0);
    #endif

    cloud = (skyLighting + groundLighting) * 0.25 * rPI + directLighting;

    #ifdef RAINY_CLOUDS
        // Storm clouds: dark, low-contrast and grey.
        float wet = clamp01(wetness);
        vec3 stormShade = mix(vec3(1.0), vec3(0.5, 0.53, 0.58), wet * RAIN_CLOUD_DARKEN);
        cloud *= stormShade;
        cloud *= mix(1.0, 0.7, wet * RAIN_CLOUD_DARKEN);
    #endif

    cloudHitPos /= totTransmit;
    cloudHitPos -= cameraPosition;

	vec3 kCamera = vec3(0.0, cameraPosition.y * 0.001 + ATMOSPHERE.bottom_radius + 0.05, 0.0);
	vec3 kPoint  = cloudHitPos * 0.001 + kCamera;
	
    vec3 transmitAP;
    vec3 in_scatter_moon;
    vec3 in_scatter = GetSkyRadianceToPoint(ATMOSPHERE, colortex7, colortex7, colortex7, kCamera, kPoint, 0.0, wSunVector, transmitAP, in_scatter_moon) * SKY_SPECTRAL_RADIANCE_TO_LUMINANCE;
    in_scatter_moon *= SKY_SPECTRAL_RADIANCE_TO_LUMINANCE_MOON;
    in_scatter += in_scatter_moon;
	
	cloud = cloud * transmitAP + in_scatter * (1.0 - transmit);
    
    return;
}

// Absorb sunlight through the clouds.
float CalculateCloudShadows(vec3 position, vec3 direction, const int steps){
    #ifndef VC_SHADOWS
        return 1.0;
    #endif
    #ifndef VOLUMETRIC_CLOUDS
        return 1.0;
    #endif

    float rSteps = volumetric_cloudThickness / steps;
    float stepSize = rSteps / abs(direction.y);

    vec3 increment = direction * stepSize;

    float fade = smoothstep(0.125, 0.075, abs(direction.y));

    // Make sure the shadows keep on going even after we absorbed through the cloud.
    position += position.y <= volumetric_cloudMinHeight ? direction * (volumetric_cloudMinHeight - position.y) / direction.y : vec3(0.0);

    float transmit = 0.0;

    for (int i = 0; i < steps; ++i, position += increment){
        transmit += CalculateCloudDensity(position, 3);
    }
	
    return exp2(-transmit * sigmaE * rLOG2 * stepSize) * (1.0 - fade) + fade;
}

#endif
