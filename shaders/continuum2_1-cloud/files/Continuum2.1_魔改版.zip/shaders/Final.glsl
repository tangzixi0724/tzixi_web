/********************************************************
    © 2020 Continuum Graphics LLC. All Rights Reserved
 ********************************************************/

#include "/ContinuumLib/Syntax.glsl"

#define Final_glsl 50
#define DynamicShaderStage Final_glsl


varying vec2 texcoord;


/***********************************************************************/
#if defined vsh

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;

uniform float fov;

#include "/ContinuumLib/Utilities.glsl"

#include "/ContinuumLib/Uniform/ProjectionMatrices.glsl"

void main() {
    texcoord = gl_Vertex.xy;

    gl_Position = vec4(gl_Vertex.xy * 2.0 - 1.0, 0.0, 1.0);
}

#endif
/***********************************************************************/



/***********************************************************************/
#if defined fsh

#include "/ContinuumLib/Debug.glsl"

uniform sampler2D colortex4;
uniform sampler2D colortex8;
uniform sampler2D colortex9;
uniform sampler2D colortex10;
uniform sampler2D colortex11;
uniform sampler2D colortex12;
uniform sampler2D colortex13;
uniform sampler2D colortex14;
uniform sampler2D colortex15;
uniform sampler2D colortex16;
uniform sampler2D colortex17;
uniform sampler2D colortex18;

uniform float fov;

/* DRAWBUFFERS:0 */
layout (location = 0) out vec4 Buffer0;
#define LAYOUT_0 Buffer0
#include "/ContinuumLib/Exit.glsl"

#include "/ContinuumLib/Syntax.glsl"
#include "/ContinuumLib/Utilities.glsl"

#include "/ContinuumLib/Uniform/ProjectionMatrices.glsl"

#include "/ContinuumLib/Fragment/ColorCorrection.glsl"

void main() {
	
    vec3 color = texture(colortex4, texcoord).rgb;

    #ifdef LUT
        // LUT styles: 0=redux film, 1=retro, 2=Japanese fresh, 3=Euro fashion,
        // 4=fantasy fairy tale, 5=fresh plants, 6=minimalist modern,
        // 7=cinema, 8=anime (Shinkai), 9=glow atmosphere, 10=Horizon: Forbidden West
        #if LUT_STYLE == 1
            color = mix(color, Lookup(color, colortex9), LUT_STRENGTH);
        #elif LUT_STYLE == 2
            color = mix(color, Lookup(color, colortex10), LUT_STRENGTH);
        #elif LUT_STYLE == 3
            color = mix(color, Lookup(color, colortex11), LUT_STRENGTH);
        #elif LUT_STYLE == 4
            color = mix(color, Lookup(color, colortex12), LUT_STRENGTH);
        #elif LUT_STYLE == 5
            color = mix(color, Lookup(color, colortex13), LUT_STRENGTH);
        #elif LUT_STYLE == 6
            color = mix(color, Lookup(color, colortex14), LUT_STRENGTH);
        #elif LUT_STYLE == 7
            color = mix(color, Lookup(color, colortex15), LUT_STRENGTH);
        #elif LUT_STYLE == 8
            color = mix(color, Lookup(color, colortex16), LUT_STRENGTH);
        #elif LUT_STYLE == 9
            color = mix(color, Lookup(color, colortex17), LUT_STRENGTH);
        #elif LUT_STYLE == 10
            color = mix(color, Lookup(color, colortex18), LUT_STRENGTH);
        #else
            color = mix(color, Lookup(color, colortex8), LUT_STRENGTH);
        #endif
    #endif

    Buffer0 = vec4(color, 1.0);
	
	exit();
}

#endif
/***********************************************************************/
