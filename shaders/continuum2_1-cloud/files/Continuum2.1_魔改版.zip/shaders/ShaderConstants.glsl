/********************************************************
    © 2020 Continuum Graphics LLC. All Rights Reserved
 ********************************************************/

/*******************************************************************************
 - Settings
 ******************************************************************************/

/*
const int colortex0Format = RGBA8;  //Encoded Luminance 
const int colortex1Format = RGBA8;  //Albedo
const int colortex2Format = RGBA16; //Big Data
const int colortex3Format = RGBA16F;  //Misc Data (Unused in base)
const int colortex4Format = RGBA8;  //Feedback
const int colortex5Format = RGBA16;  //Rain and metal albedo
const int colortex6Format = R16;    //Flat encoded normal

const bool colortex0Clear = false;
const bool colortex1Clear = true;
const bool colortex2Clear = true;
const bool colortex3Clear = false;
const bool colortex4Clear = false;

const vec4 colortex1ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex2ClearColor = vec4(0.0, 0.0, 0.0, 0.0);

const bool shadowtex0Mipmap = true;
const bool shadowtex1Mipmap = true;
const bool shadowcolor0Mipmap = true;
const bool shadowcolor1Mipmap = true;

const int shadowMapResolution = 2048; // [1024 2048 3072 4096 8192]
const float shadowDistance = 140;   // [70 140 280]

const float	sunPathRotation = -25.0;
const float ambientOcclusionLevel = 0.0;

const float eyeBrightnessHalflife = 10.0;

const float wetnessHalflife = 180.0;
const float drynessHalflife = 60.0;
*/

const int noiseTextureResolution = 64;
const float rNoiseTexRes = 1.0 / noiseTextureResolution;