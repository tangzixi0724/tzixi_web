/********************************************************
    © 2020 Continuum Graphics LLC. All Rights Reserved
 ********************************************************/

#include "/ContinuumLib/GLSL_Version.glsl"
#define ShaderStage -10
#define WORLD_1
#define fsh
#define shadow

#include "/Shadow.glsl"
