/********************************************************
    © 2020 Continuum Graphics LLC. All Rights Reserved
 ********************************************************/

#include "/ContinuumLib/GLSL_Version.glsl"
#define ShaderStage 32
#define WORLD_1
#define fsh

#include "/Composite2.glsl"
