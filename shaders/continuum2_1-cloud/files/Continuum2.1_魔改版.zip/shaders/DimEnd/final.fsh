/********************************************************
    © 2020 Continuum Graphics LLC. All Rights Reserved
 ********************************************************/

#include "/ContinuumLib/GLSL_Version.glsl"
#define ShaderStage 50
#define final
#define WORLD_1
#define fsh

#include "/Final.glsl"
