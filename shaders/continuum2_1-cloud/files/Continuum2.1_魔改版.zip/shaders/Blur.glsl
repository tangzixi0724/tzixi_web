/********************************************************
    © 2020 Continuum Graphics LLC. All Rights Reserved
 ********************************************************/

#include "/ContinuumLib/Syntax.glsl"

#define Blur_glsl 38
#define DynamicShaderStage Blur_glsl


varying vec2 texcoord;
varying float centerDepth;

/***********************************************************************/
#if defined vsh

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;

uniform sampler2D depthtex0;

uniform float fov;

#include "/ContinuumLib/Utilities.glsl"

#include "/ContinuumLib/Uniform/ProjectionMatrices.glsl"

void main() {
    texcoord = gl_Vertex.xy;
    centerDepth = texture(depthtex0, vec2(0.5)).r;

    gl_Position = vec4(gl_Vertex.xy * 2.0 - 1.0, 0.0, 1.0);
}

#endif
/***********************************************************************/



/***********************************************************************/
#if defined fsh

#include "/ContinuumLib/Debug.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D depthtex0;

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;

uniform vec2 viewDimensions;
uniform vec2 pixelSize;

uniform float aspectRatio;
uniform float fov;

/* DRAWBUFFERS:0123 */
layout (location = 0) out vec4 Buffer0;
layout (location = 1) out vec4 Buffer1;
layout (location = 2) out vec4 Buffer2;
#define LAYOUT_0 Buffer0
#include "/ContinuumLib/Exit.glsl"

const bool colortex3MipmapEnabled = true;

#include "/ContinuumLib/Utilities.glsl"

#include "/ContinuumLib/Uniform/ProjectionMatrices.glsl"
#include "/ContinuumLib/Common/MatID.glsl"

float ScreenToViewSpaceDepth(float depth) {
    depth = depth * 2.0 - 1.0;
    return -1.0 / (depth * gbufferProjectionInverse[2][3] + gbufferProjectionInverse[3][3]);
}

vec2 CalculateDistOffset(const vec2 prep, const float angle, const vec2 offset) {
    return offset * angle + prep * dot(prep, offset) * (1.0 - angle);
}

// iterationT 3.2.0 style depth of field:
// physical circle-of-confusion, a foreground "spread" pass (bright foreground
// bleeds into the background instead of leaving hard halos), then a gather with
// a soft golden-angle disk. The bokeh is round and smooth, no hard blades.
float GetLinearDepth(vec2 coord) {
    return max(ScreenToViewSpaceDepth(textureLod(depthtex0, coord, 0.0).x), 1e-4);
}

float CalculateFocusDistance() {
    #if CAMERA_FOCUS_MODE == 0
        float focus = ScreenToViewSpaceDepth(centerDepth) - CAMERA_AUTO_FOCAL_OFFSET;
        // Keep auto focus sane: a sky/very-near center would otherwise push the
        // focal plane to an extreme and blur everything uniformly (Gaussian look).
        focus = clamp(focus, 4.0, 300.0);
    #else
        float focus = CAMERA_FOCAL_POINT;
    #endif
    return max(focus, 0.01);
}

float CalculateCoCRadius(float f, float d, float a) {
    return abs(a * (d - f) / (d * f));
}

// Expands the circle of confusion where nearby foreground pixels with a large
// CoC would cover this pixel, so foreground bokeh blends into the background.
float CoCSpread() {
    float cocRadiusfactor = DOF_BLUR * gbufferProjection[1][1];
    const float maxCoc = DOF_MAX_COC;
    const float rMaxCoc = 1.0 / maxCoc;
    float rAspectRatio = 1.0 / aspectRatio;

    float currDepth = GetLinearDepth(texcoord);
    float focus = CalculateFocusDistance();
    float currCoc = CalculateCoCRadius(focus, currDepth, cocRadiusfactor);

    float startRadius = currCoc * rMaxCoc;
    startRadius *= startRadius;

    float spreadCoc = currCoc;

    const float steps = float(DOF_COCSPREAD_QUALITY);
    const float rSteps = 1.0 / steps;
    const mat2 rotMat = mat2(cos(goldenAngle), sin(goldenAngle), -sin(goldenAngle), cos(goldenAngle));
    float angle = bayer64(gl_FragCoord.xy) * TAU;
    vec2 rot = vec2(cos(angle), sin(angle));

    for (float i = 0.0; i < steps; i++) {
        rot *= rotMat;
        float sampleRadius = sqrt(startRadius + i * (1.0 - startRadius) * rSteps) * maxCoc;
        vec2 sampleCoordOffset = rot * sampleRadius;
        sampleCoordOffset.x *= rAspectRatio;
        vec2 sampleCoord = texcoord + sampleCoordOffset;

        float sampleDepth = GetLinearDepth(sampleCoord);
        float sampleCoC = CalculateCoCRadius(focus, sampleDepth, cocRadiusfactor);

        if (sampleCoC >= sampleRadius && sampleDepth <= currDepth) {
            spreadCoc = max(spreadCoc, sampleCoC);
        }
    }

    return min(spreadCoc, maxCoc) * rMaxCoc;
}

vec3 DepthOfField(bool isHand) {
    #ifndef DOF
        return DecodeColor(textureLod(colortex3, texcoord, 0).rgb);
    #endif

    if (isHand) return DecodeColor(textureLod(colortex3, texcoord, 0).rgb);

    float cocRadiusfactor = DOF_BLUR * gbufferProjection[1][1];
    float minCoc = 0.5641895835 * pixelSize.y;
    const float maxCoc = DOF_MAX_COC;
    float rAspectRatio = 1.0 / aspectRatio;

    float currDepth = GetLinearDepth(texcoord);
    float focus = CalculateFocusDistance();
    float currCoc = CalculateCoCRadius(focus, currDepth, cocRadiusfactor);
    currCoc = clamp(currCoc, minCoc, maxCoc);

    float spreadCoc = max(CoCSpread() * maxCoc, currCoc);

    float centerWeight = spreadCoc * spreadCoc - spreadCoc + 1.0;
    centerWeight = mix(centerWeight, 1e-20, pow(currCoc / spreadCoc, 4.0));

    vec3 dof = vec3(0.0);
    float weights = 0.0;
    vec3 selfColor = DecodeColor(textureLod(colortex3, texcoord, 0).rgb) * 1e-20;
    float selfSamples = 1e-20;
    float selfWeights = 0.0;

    const float steps = float(DOF_QUALITY);
    const float rSteps = 1.0 / steps;
    const mat2 rotMat = mat2(cos(goldenAngle), sin(goldenAngle), -sin(goldenAngle), cos(goldenAngle));
    float dither = bayer64(gl_FragCoord.xy);
    float angle = dither * TAU;
    vec2 rot = vec2(cos(angle), sin(angle));

    for (float i = 0.0; i < steps; i++) {
        rot *= rotMat;
        float sampleRadius = sqrt((i + dither) * rSteps) * spreadCoc;
        vec2 sampleCoordOffset = rot * sampleRadius;
        sampleCoordOffset.x *= rAspectRatio;
        vec2 sampleCoord = texcoord + sampleCoordOffset;

        float sampleDepth = GetLinearDepth(sampleCoord);
        float sampleCoC = CalculateCoCRadius(focus, sampleDepth, cocRadiusfactor);
        sampleCoC = clamp(sampleCoC, minCoc, maxCoc);
        vec3 sampleColor = DecodeColor(textureLod(colortex3, sampleCoord, 0).rgb);

        if (currCoc >= sampleRadius && sampleDepth >= currDepth) {
            // Same or farther depth inside the focused disk: keep it sharp.
            selfColor += sampleColor;
            selfSamples += 1.0;
        } else if (sampleCoC >= sampleRadius && sampleDepth < currDepth) {
            // Nearby foreground with a CoC covering this pixel: bleed it in.
            float sampleWeight = max(1.0, currCoc / sampleCoC);
            sampleWeight *= sampleWeight;
            dof += sampleColor * sampleWeight;
            weights += sampleWeight;
        } else {
            selfWeights += centerWeight;
        }
    }

    dof += selfColor * (1.0 + selfWeights / selfSamples);
    dof /= weights + selfSamples + selfWeights;

    return max0(dof);
}

vec3 CalculateBloomTile(const float lod, vec2 pixelSize, vec2 offset) {
    #ifndef BLOOM
        return vec3(0.0);
    #endif

    vec2 coord = (texcoord - offset) * exp2(lod);
    vec2 scale = pixelSize * exp2(lod);

    if (any(greaterThanEqual(abs(coord - 0.5), scale + 0.5)))
        return vec3(0.0);

    vec3 bloom = vec3(0.0);
    float totalWeight = 0.0;

    const int bloomSamples = BLOOM_SAMPLES - 1;
    const float invSamples = 1.0 / float(bloomSamples + 1.0);

    for (int y = -bloomSamples; y <= bloomSamples; ++y) { // 5
        for (int x = -bloomSamples; x <= bloomSamples; ++x) { // 5
            float sampleLength = 1.0 - length(vec2(x, y)) * invSamples; //div by sqrt of total samples
            float sampleWeight = clamp01(pow(sampleLength, BLOOM_CURVE));

            bloom += textureLod(colortex3, coord + vec2(x, y) * scale, lod).rgb * sampleWeight;

            totalWeight += sampleWeight;
        }
    }

    return bloom / totalWeight;
}

vec3 CalculateBloomTiles() {
    #ifndef BLOOM
        return vec3(0.0);
    #endif

    vec3 bloom  = vec3(0.0);
        bloom += CalculateBloomTile(2.0, pixelSize, vec2(0.0, 0.0));
        bloom += CalculateBloomTile(3.0, pixelSize, vec2(0.0, 0.25 + pixelSize.y * 2.0));
        bloom += CalculateBloomTile(4.0, pixelSize, vec2(0.125 + pixelSize.x * 2.0, 0.25 + pixelSize.y * 2.0));
        bloom += CalculateBloomTile(5.0, pixelSize, vec2(0.1875 + pixelSize.x * 4.0, 0.25 + pixelSize.y * 2.0));
        bloom += CalculateBloomTile(6.0, pixelSize, vec2(0.125 + pixelSize.x * 2.0, 0.3125 + pixelSize.y * 4.0));
        bloom += CalculateBloomTile(7.0, pixelSize, vec2(0.140625 + pixelSize.x * 4.0, 0.3125 + pixelSize.y * 4.0));

    return DecodeColor(max0(bloom));
}

void main() {
    vec4 materialData = textureRaw(colortex2, texcoord);
    vec2 decode2y = Decode2x8(materialData.y);

    float materialID;
    UnpackMaterialID(decode2y.y, materialID);

    bool isHand = materialID == 12.0;

    vec3 color = DepthOfField(isHand);

    #ifdef BOKEH_DEBUG
        if(all(lessThanEqual(texcoord / vec2(1.0, aspectRatio), vec2(0.25))))
            color  = texture(colortex0, (texcoord * 4.0) / vec2(1.0, aspectRatio)).rgb;
    #endif

    //Calculate DoF
    Buffer0 = EncodeRGBE8(color);

    //Calculate Bloom Tiles
    Buffer1 = EncodeRGBE8(CalculateBloomTiles());

    vec3 buffer2Passthrough = texture(colortex2, texcoord).rgb;
    float EV = texture(colortex3, texcoord).a;
    
    Buffer2 = vec4(buffer2Passthrough, EV * 0.1);
    
	exit();
}

#endif
/***********************************************************************/
