/********************************************************
    Continuum 2.1 Alpha Build 12 (Iris) - Voxy translucent patch
    Encodes Voxy LOD quads into Continuum's gbuffer layout.
    Water quads (customId 8/9) get materialID 5 (water) + a faint blue tint;
    other translucent quads keep their real albedo as plain terrain so they
    are never mistaken for water.
    Personal use compatibility patch.
 ********************************************************/

layout(location = 0) out vec4 vxBuffer1;
layout(location = 1) out vec4 vxBuffer2;
layout(location = 2) out vec4 vxBuffer6;

float vxEncode2x8(vec2 a) {
    return dot(floor(clamp(a, 0.0, 1.0) * 255.0), vec2(1.0, 256.0) / 65535.0);
}

// Continuum octahedral normal encoding (same as ContinuumLib/Utilities/Encoding.glsl)
float vxEncodeNormal(vec3 n) {
    vec3 b = abs(n);
    vec2 p = n.xy / (b.x + b.y + b.z);
    vec2 e = n.z <= 0.0 ? (1.0 - abs(p.yx)) * sign(p) : p;
    return vxEncode2x8(e * 0.5 + 0.5);
}

void voxy_emitFragment(VoxyFragmentParameters parameters) {
    // Water (and flowing water) are block IDs 8 and 9 in our block.properties,
    // which Voxy forwards through parameters.customId (Iris blockStateId).
    // Every other translucent quad (glass, ice, leaves, ...) must NOT be
    // treated as water, otherwise far-away non-water surfaces would get the
    // water material and render black.
    bool isWater = parameters.customId == 8u || parameters.customId == 9u;

    // Axis-aligned world space normal from the quad face
    vec3 normal = vec3(
        float((parameters.face >> 1) == 2u),
        float((parameters.face >> 1) == 0u),
        float((parameters.face >> 1) == 1u)
    ) * (float(int(parameters.face) & 1) * 2.0 - 1.0);

    // Voxy lightmap is (sky, block), Continuum gbuffer expects (block, sky)
    vec2 lightmaps = vec2(parameters.lightMap.y, parameters.lightMap.x);

    vec4 materialData;
    if (isWater) {
        // Water material: roughness 0.1, materialID 5 (water)
        materialData.x = vxEncodeNormal(normal);
        materialData.y = vxEncode2x8(vec2(0.1, 5.0 * 0.03125));
        materialData.z = vxEncode2x8(vec2(lightmaps.x, clamp(lightmaps.y * (15.0 / 255.0 + 1.0), 0.0, 1.0)));
        materialData.w = vxEncode2x8(vec2(1.0, 1.0));

        // A faint blue tint instead of pure black so distant LOD water never
        // falls back to a black albedo when the background lookup is empty.
        vxBuffer1 = vec4(0.02, 0.10, 0.16, 0.02);
    } else {
        // Default rough terrain material, using the actual sampled albedo so
        // glass/leaves keep their own colour instead of being forced to water.
        materialData.x = vxEncodeNormal(normal);
        materialData.y = vxEncode2x8(vec2(1.0, 2.0 * 0.03125));
        materialData.z = vxEncode2x8(vec2(lightmaps.x, clamp(lightmaps.y * (15.0 / 255.0 + 1.0), 0.0, 1.0)));
        materialData.w = vxEncode2x8(vec2(1.0, 1.0));

        vxBuffer1 = vec4(parameters.sampledColour.rgb * parameters.tinting.rgb, parameters.sampledColour.a);
    }

    vxBuffer2 = materialData;
    vxBuffer6 = vec4(vxEncodeNormal(normal), 0.0, 0.0, 1.0);
}
