#if !defined _SETTINGSMANAGER_
#define _SETTINGSMANAGER_

#define CAMERA_AUTO 0
#define CAMERA_MANUAL 1

#define DOF_AUTO 0
#define DOF_MANUAL 1

#include "../UserLib/Misc/AntialiasingSettings.glsl"
#include "../UserLib/Misc/MiscSettings.glsl"
#include "../UserLib/Misc/ParallaxSettings.glsl"
#include "../UserLib/Misc/VertexSettings.glsl"
#include "../UserLib/Toning/ToningSettings.glsl"
#include "../UserLib/PostProcess/PostProcessSettings.glsl"
#include "../UserLib/Camera/CameraSettings.glsl"
#include "../UserLib/Lighting/ShadowSettings.glsl"
#include "../UserLib/Lighting/DiffuseSettings.glsl"
#include "../UserLib/Lighting/AOSettings.glsl"
#include "../UserLib/Lighting/SpecularSettings.glsl"
#include "../UserLib/Lighting/VolumetricLightSettings.glsl"
#include "../UserLib/Lighting/CausticsSettings.glsl"
#include "../UserLib/Sky/CloudConstants.glsl"
#include "../UserLib/Sky/SkyConstants.glsl"

#endif
