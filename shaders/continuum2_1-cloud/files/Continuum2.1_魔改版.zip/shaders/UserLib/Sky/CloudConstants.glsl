#if !defined _CLOUDCONSTANTS_
#define _CLOUDCONSTANTS_

//#define VOLUMETRIC_CLOUDS
#define VC_QUALITY 24 //[5 10 15 20 24 32 64 128 256 512]
#define VC_SUNLIGHT_QUALITY 12 //[2 3 4 5 6 7 8 9 10 12 14 16 18 20 22 24 26 28 30 32 36 40 44 48 52 56 60 64]
#define VC_NOISE_OCTAVES 5 //[3 4 5 6 7 8]
#define VC_LOCAL_COVERAGE
//#define VC_SHADOWS
#define VC_MULTISCAT_TERMS 8  //[1 2 3 4 5 6 7 8 9 10 12 14 16 32]
#define VC_GROUND_LIGHTING
#define VC_HQ_SKYLIGHTING 

#define volumetric_cloudThicknessMult 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0]
#define volumetric_cloudDensity 1.0  //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.0 3.1 3.2 3.3 3.4 3.5 3.6 3.7 3.8 3.9 4.0 4.1 4.2 4.3 4.4 4.5 4.6 4.7 4.8 4.9 5.0 5.1 5.2 5.3 5.4 5.5 5.6 5.7 5.8 5.9 6.0 6.1 6.2 6.3 6.4 6.5 6.6 6.7 6.8 6.9 7.0 7.1 7.2 7.3 7.4 7.5 7.6 7.7 7.8 7.9 8.0]
#define volumetric_cloudHeight 1600.0   //[100.0 110.0 120.0 130.0 140.0 160.0 180.0 200.0 220.0 240.0 260.0 280.0 300.0 400.0 500.0 600.0 700.0 800.0 900.0 1000.0 1200.0 1400.0 1600.0 1800.0 2000.0 10000.0]
#define volumetric_cloudMinHeight volumetric_cloudHeight
#define volumetric_cloudCoverage 1.0    //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define volumetric_cloudSpeed 1.0       //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0 3.5 4.0 4.5 5.0 5.5 6.0]

const float volumetric_cloudThickness = 1500.0 * volumetric_cloudThicknessMult;
const float volumetric_cloudMaxHeight = volumetric_cloudMinHeight + volumetric_cloudThickness;

#define PLANAR_CLOUDS
#define PLANAR_CLOUDS_HEIGHT 9000.0 //[5000.0 5500.0 6000.0 6500.0 7000.0 7500.0 8000.0 8500.0 9000.0 9500.0 10000.0 11000.0 12000.0 13000.0]

// Increased layer thickness makes the cloud tops/bottoms fade in much more softly (iterationT style).
const float PLANAR_CLOUDS_THICKNESS = 1000.0;

#define PLANAR_CLOUDS_MULTISCSAT_QUALITY 8 //[1 2 3 4 5 6 7 8 9 10 12 14 16 32]

// Rainy clouds: denser, heavier and darker like real storm clouds.
#define RAINY_CLOUDS
#define RAIN_CLOUD_DENSITY 1.2 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define RAIN_CLOUD_COVERAGE 0.7 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define RAIN_CLOUD_DARKEN 0.45 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#endif
