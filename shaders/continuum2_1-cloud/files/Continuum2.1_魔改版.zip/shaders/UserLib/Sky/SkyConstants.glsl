#define PLANET_SURFACE

// 地天 (Atmosphere Ground, like Bliss): darkens the sky below the horizon as if
// the ground extends to infinity. The transition is a wide, smooth gradient so the
// dark region blends into the sky's own colour. Default ON; turn off for the
// original sky.
#define SKY_GROUND
#define SKY_GROUND_STRENGTH 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.25 1.5 1.75 2.0]

// Sun brightness: scales the visible sun disc and the direct sunlight it casts.
// Higher = brighter sun, lower = dimmer sun.
#define SUN_BRIGHTNESS 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.25 1.5 1.75 2.0 2.5 3.0 4.0 5.0]

//TODO: Bring in LUT settings :)
