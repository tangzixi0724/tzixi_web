#define WAVING_PLANTS

#ifdef WAVING_PLANTS

#endif