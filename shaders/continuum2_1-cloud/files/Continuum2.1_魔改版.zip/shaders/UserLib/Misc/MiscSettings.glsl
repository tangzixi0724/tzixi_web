//#define WHITE_WORLD
//#define HIDE_PLAYER_SHADOW

#define RAIN_PUDDLES

// Lab PBR materials: reads the specular (_s) texture with the Lab PBR channel
// layout (R smoothness, G f0, B porosity, A emissive) and enables metallic,
// emissive and porous (SSS) behaviour. Vanilla blocks are unaffected.
#define LAB_PBR

#define REFRACTION
//#define BILINEAR_TEXTURES
