#if !defined _SHADOWSETTINGS_
#define _SHADOWSETTINGS_

/*******************************************************************************
 - Shadow Settings
 ******************************************************************************/

#define SHADOW_MINIMUM 2
#define SHADOW_LOW 3
#define SHADOW_MEDIUM 9
#define SHADOW_HIGH 18
#define SHADOW_ULTRA 25
#define SHADOW_CINEMATIC 81

#define SHADOW_QUALITY SHADOW_HIGH // [SHADOW_MINIMUM SHADOW_LOW SHADOW_MEDIUM SHADOW_HIGH SHADOW_ULTRA SHADOW_CINEMATIC]
#define SHADOW_PENUMBRA_ANGLE 12.0 // [0.0 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0 21.0 22.0 23.0 24.0 25.0 26.0 27.0 28.0 29.0 30.0]

// Fills fully shadowed areas with a small amount of sun light so shadows stay soft instead of dead black (iterationT style).
#define SHADOW_AMBIENT_LIGHT 0.15 // [0.0 0.02 0.05 0.08 0.1 0.12 0.15 0.2 0.25 0.3 0.35 0.4 0.5]

// Screen-space contact shadow: the hard, near-black "inner shadow" that hugs
// the base of blocks inside the soft shadow map shadow. Default OFF so placed
// blocks no longer show a darker harder shadow; raise it to re-enable the
// grounded contact look.
#define CONTACT_SHADOW_STRENGTH 0.0 // [0.0 0.1 0.2 0.3 0.35 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define SHADOW_HARD 0
#define SHADOW_SOFT 1
#define SHADOW_PCSS 2

#define SHADOW_TYPE SHADOW_PCSS // [SHADOW_HARD SHADOW_SOFT SHADOW_PCSS]
//#define UNDERGROUND_SHADOW_FIX // Temporary fix that fixes shadows being rendered through blocks when in caves.

// Screen-space shadows: ray-marches the depth buffer toward the sun to shade
// distant terrain and Voxy LOD quads that fall outside the shadow map (the LOD
// geometry can only receive screen-space shadows). Default OFF; enable it when
// you want distant landscape / LOD shadows.
//#define DISTANT_SHADOWS
#define DISTANT_SHADOW_DISTANCE 512.0 // [128.0 192.0 256.0 384.0 512.0 768.0 1024.0 1536.0 2048.0]
#define DISTANT_SHADOW_STEPS 32 // [8 10 12 16 20 24 32 40 48 64]
#define DISTANT_SHADOW_STRENGTH 0.85 // [0.3 0.4 0.5 0.6 0.7 0.8 0.85 0.9 1.0]

const int shadowMapResolution = 2048; // [256 512 1024 2048 3072 4096 8192 16384]
const float rShadowMapResolution = 1.0 / float(shadowMapResolution);
const float shadowDistance    = 120.0;

#define CAUSTICS

#endif
