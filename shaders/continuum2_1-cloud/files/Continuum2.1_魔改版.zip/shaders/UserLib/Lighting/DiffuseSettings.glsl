#if !defined _DIFFUSESETTINGS_
#define _DIFFUSESETTINGS_

/*******************************************************************************
 - Diffuse Lighting Settings
 ******************************************************************************/

#define RSM // Reflective shadow maps (Global Illumination)

#define RSM_RADIUS 25.0 //[10.0 25.0 50.0 100.0 150.0 200.0 250.0 300.0]
#define RSM_QUALITY 16 //[8 16 32 64 128]

#define LIGHT_TEMP 2700 //[2500 2600 2700 2800 2900 3000 3200 3400 3600 3800 4000 4300 4600 4900 5200 5500 5800 6100 6400]
#define LIGHT_LUM 500   //[100 200 300 400 500 600 700 800 900 1000 1200 1400 1600 1800 2000]

#define NETHER_AMBIENT_LUM 0.0025
#define END_AMBIENT_LUM vec3(1.6, 0.86, 2.1)

#endif
