#if !defined _AOSETINGS_
#define _AOSETINGS_

#define AO
#define AO_NUM_DIRECTIONS 8 //[2 4 6 8 10 12 14 16 32 64]
#define AO_NUM_STEPS 16 //[2 4 6 8 10 12 14 14 16 32 64]

#ifdef AO
#endif

#endif