#if !defined _TIMEOVERRIDE_
#define _TIMEOVERRIDE_

//This file will be for The Custom Shadow Matricies settings and custom functions
//Things like camera position, position, frame counter, stuff like that should be available to make different shadow curves.

//#define TELEFOCAL_SHADOWS
#define TELEFOCAL_SHADOWS_DISTANCE 50
//#define TIME_OVERRIDE

#ifdef TIME_OVERRIDE
    // This (or something similar) should probably be somewhere in UserLib, but I don't know where I should put it there.
    // Currently it serves mostly just as an example.
    void TimeOverride(inout float timeAngle, inout float pathRotationAngle, inout float twistAngle) {
        twistAngle = 90.0;
    }
#endif

#endif
