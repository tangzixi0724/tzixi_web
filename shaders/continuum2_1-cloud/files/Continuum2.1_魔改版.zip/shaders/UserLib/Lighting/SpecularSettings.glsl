#if !defined _SPECULARSETTINGS_
#define _SPECULARSETTINGS_

#define SPECULAR_QUALITY 2 //[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 22 24 26 28 30 32]
#define RAYTRACE_QUALITY 16 //[8 16 32 64 128 256 512]

#define RAYTRACE_REFINEMENT //Improves ray trace quality by refining the rays with minimal performance overhead.
#define RAYTRACE_REFINEMENT_STEPS 6 //[2 3 4 5 6 7 8 9 10 12 14 16 18 20 22 24 26 28 30 32]

#define SPECULAR_TAIL_CLAMP 0.3 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7] Controls the "tail" length of the specular distribution. Higher values lowers the maximum tail length. Higher values reduces noise at the cost of quality.

#endif