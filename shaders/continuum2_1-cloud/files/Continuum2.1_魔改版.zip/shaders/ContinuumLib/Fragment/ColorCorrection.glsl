/********************************************************
    © 2020 Continuum Graphics LLC. All Rights Reserved
 ********************************************************/

#if !defined _COLORCORRECTION_
#define _COLORCORRECTION_

struct ColorCorrection {
	vec3 lum;
	float saturation;
	float vibrance;
	
	float contrast;
	float contrastMidpoint;

	vec3 gain;
	vec3 lift;
	vec3 invGamma;
};

vec3 Saturation(const vec3 color, const ColorCorrection m) {
	float grey = dot(color, m.lum);
	return grey + m.saturation * (color - grey);
}

vec3 Vibrance(const vec3 color, const ColorCorrection m) {
	float maxColor = max3(color.r, color.g, color.b);
	float minColor = min3(color.r, color.g, color.b);

	float colorSaturation = maxColor - minColor;

	float grey = dot(color, m.lum);
	
	return mix(vec3(grey), color, 1.0 + m.vibrance * (1.0 - sign(m.vibrance) * colorSaturation));
}

vec3 LogContrast(const vec3 x, const float contrast) {
	const float contrastEpsilon = 1e-5;
	const float logMidpoint = log2(0.18);

	vec3 logX = log2(x + contrastEpsilon);
	vec3 adjX = (logX - logMidpoint) * contrast + logMidpoint;

	return max0(exp2(adjX) - contrastEpsilon);
}

vec3 Contrast(const vec3 color, const ColorCorrection m) {
	return LogContrast(color, m.contrast);
}

vec3 LiftGammaGain(const vec3 v, const ColorCorrection m) {
	vec3 lerpV = clamp01(pow(v, m.invGamma));
	return m.gain * lerpV + m.lift * (1.0 - lerpV);
}

// 64x64x64 2D lookup-table grade (same layout as continuum-2.0-redux):
// the blue channel selects a tile, red/green sample inside it, with
// interpolation between the two neighbouring blue slices.
vec3 Lookup(vec3 color, sampler2D lookupTable) {
    float blueColor = color.b * 63.0;

    vec4 quad = vec4(0.0);
    quad.y = floor(floor(blueColor) * 0.125);
    quad.x = floor(blueColor) - (quad.y * 8.0);
    quad.w = floor(ceil(blueColor) * 0.125);
    quad.z = ceil(blueColor) - (quad.w * 8.0);

    vec4 texPos = (quad * 0.125) + (0.123046875 * color.rg).xyxy + 0.0009765625;

    vec3 newColor1 = texture(lookupTable, texPos.xy).rgb;
    vec3 newColor2 = texture(lookupTable, texPos.zw).rgb;

    return mix(newColor1, newColor2, fract(blueColor));
}

#endif
